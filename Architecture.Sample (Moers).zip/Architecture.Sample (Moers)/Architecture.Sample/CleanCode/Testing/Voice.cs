﻿using System;

namespace Architecture.Sample.CleanCode.Testing
{
    public class Voice : ICanTalk
    {
        public void Say(string text)
        {
            Console.WriteLine(text);
        }

        public void Shout(string text)
        {
            Console.WriteLine(text);
        }
    }
}