﻿using System;

namespace Architecture.Sample.CleanCode.Testing
{
    public class Character
    {
        private HealthStatus _healthStatus;

        public Character(HealthStatus healthStatus)
        {
            _healthStatus = healthStatus;
        }
        public bool Defend(AttackType attackType)
        {
            switch (attackType)
            {
                case AttackType.Pat:
                    _healthStatus = HealthStatus.Healthy;
                    break;
                case AttackType.Punch:
                    _healthStatus = HealthStatus.Unhealthy;
                    break;
                case AttackType.MightyBlow:
                    _healthStatus = HealthStatus.Dead;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(attackType), attackType, null);
            }

            return false;
        }

        public bool IsHealthy()
        {
            return _healthStatus == HealthStatus.Healthy;
        }
        public bool IsDead()
        {
            return _healthStatus == HealthStatus.Dead;
        }
    }
}