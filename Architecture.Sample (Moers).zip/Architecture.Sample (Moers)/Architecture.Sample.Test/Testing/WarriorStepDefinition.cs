﻿using Architecture.Sample.CleanCode.Testing;
using FakeItEasy;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace Architecture.Sample.Test.Testing
{
    [Binding]
    public class WarriorStepDefinition
    {
        private Character _opponent;
        private Warrior _warrior;

        [Given("the healthy opponent")]
        public void GivenTheHealthyOpponent()
        {
            _opponent = new Character(HealthStatus.Healthy);
        }

        [Given("the healthy warrior")]
        public void GivenTheHealthyWarrior()
        {
            _warrior = new Warrior(A.Fake<ICanTalk>(), HealthStatus.Healthy);
        }

        [Then("the opponent looks unhealthy")]
        public void ThenTheOpponentLooksUnhealthy()
        {
            _opponent.IsHealthy().Should().BeFalse();
        }

        [When("the warrior attacks the opponent")]
        public void WhenTheWarriorAttacksTheOpponent()
        {
            _warrior.Attack(_opponent);
        }
    }
}