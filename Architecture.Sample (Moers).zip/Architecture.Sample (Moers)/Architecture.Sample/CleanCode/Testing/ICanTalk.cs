﻿namespace Architecture.Sample.CleanCode.Testing
{
    public interface ICanTalk
    {
        void Say(string text);
        void Shout(string text);
    }
}