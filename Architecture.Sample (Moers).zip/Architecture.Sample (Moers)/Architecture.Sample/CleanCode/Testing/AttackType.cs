﻿namespace Architecture.Sample.CleanCode.Testing
{
    public enum AttackType
    {
        Pat,
        Punch,
        MightyBlow,
    }
}