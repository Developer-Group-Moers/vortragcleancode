﻿namespace Architecture.Sample.CleanCode.Testing
{
    public class Warrior : Character
    {
        private readonly ICanTalk _voice;

        public Warrior(ICanTalk voice, HealthStatus healthStatus) : base(healthStatus)
        {
            _voice = voice;
        }

        public void Attack(Character opponent)
        {
            if (!opponent.Defend(AttackType.MightyBlow))
                _voice.Say("Eat this!");
        }
    }
}