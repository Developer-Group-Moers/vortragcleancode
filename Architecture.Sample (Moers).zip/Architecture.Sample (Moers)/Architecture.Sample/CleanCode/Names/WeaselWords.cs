﻿using System;

namespace Architecture.Sample.CleanCode.Names
{
    public class CharacterManager
    {
        public int PossibleAttack(int opponentDefensiveValue)
        {
            var someHit = new Random().Next(0, 10);
            var somethingMightHappen = someHit - opponentDefensiveValue;

            return somethingMightHappen <= 0 ? 0 : somethingMightHappen;
        }
    }
}