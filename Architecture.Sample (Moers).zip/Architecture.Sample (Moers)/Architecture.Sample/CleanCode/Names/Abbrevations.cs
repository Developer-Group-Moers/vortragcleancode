﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Architecture.Sample.CleanCode.Names
{
    public class Char
    {
        private List<Itm> _itms;

        public int Atk(int oDV)
        {
            var hit = new Random().Next(0, 10);
            var dmg = hit - oDV;

            return dmg <= 0 ? 0 : dmg;
        }

        public bool HasBags()
        {
            return _itms.Any(x => x.ItemType == ItemType.Bag);
        }

        private enum ItemType
        {
            Equipment = 0,
            Clothing = 1,
            Bag = 2
        }

        private class Itm
        {
            public ItemType ItemType { get; private set; }
        }
    }
}