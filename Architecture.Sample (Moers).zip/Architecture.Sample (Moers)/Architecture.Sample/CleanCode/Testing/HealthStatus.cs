﻿namespace Architecture.Sample.CleanCode.Testing
{
    public enum HealthStatus
    {
        Healthy,
        Unhealthy,
        Dead
    }
}