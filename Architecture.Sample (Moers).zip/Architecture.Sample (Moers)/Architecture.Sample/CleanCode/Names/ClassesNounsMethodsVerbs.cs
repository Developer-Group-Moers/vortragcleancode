﻿using System;

namespace Architecture.Sample.CleanCode.Names
{
    public class Attacking
    {
        public int Damage(int opponentDefensiveValue)
        {
            var hit = new Random().Next(0, 10);
            var damage = hit - opponentDefensiveValue;

            return damage <= 0 ? 0 : damage;
        }
    }
}