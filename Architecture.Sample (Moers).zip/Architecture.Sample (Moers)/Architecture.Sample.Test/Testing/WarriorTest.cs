using Architecture.Sample.CleanCode.Testing;
using FakeItEasy;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Architecture.Sample.Test.Testing
{
    [TestClass]
    public class WarriorTest
    {
        [TestMethod]
        public void Attack_damages_opponent()
        {
            var warrior = new Warrior(A.Fake<ICanTalk>(), HealthStatus.Healthy);
            var opponent = new Character(HealthStatus.Healthy);

            warrior.Attack(opponent);

            opponent.IsHealthy().Should().BeFalse();
        }
    }
}
