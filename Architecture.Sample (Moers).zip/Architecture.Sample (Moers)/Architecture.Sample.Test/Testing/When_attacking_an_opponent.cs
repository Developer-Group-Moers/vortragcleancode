﻿using Architecture.Sample.CleanCode.Testing;
using FakeItEasy;
using FluentAssertions;
using Machine.Specifications;

namespace Architecture.Sample.Test.Testing
{
    [Subject(typeof(Warrior), "Attack")]
    public class When_attacking_a_healthy_opponent
    {
        private static Character _opponent;

        private static Warrior _warrior;

        private Establish _context = () =>
        {
            _warrior = new Warrior(A.Fake<ICanTalk>(), HealthStatus.Healthy);
            _opponent = new Character(HealthStatus.Healthy);
        };

        private Because of = () =>
            _warrior.Attack(_opponent);

        private It should_hurt_the_opponent = () =>
            _opponent.IsHealthy().Should().BeFalse();
    }
}