﻿using System;

namespace Architecture.Sample.CleanCode.Functions
{
    public class CharacterArguments
    {
        public int Attack(int myOffensiveValue, int myDefensiveValue, int myWeight, int opponentOffensiveValue, int opponentDefensiveValue, int opponentWeight)
        {
            var hit = new Random().Next(0, 10);
            var damage = hit - opponentDefensiveValue;
            var damageModificator = CalculateBodyMassModifier(myWeight, opponentWeight);

            return damage <= 0 ? 0 : damage * damageModificator;
        }

        private int CalculateBodyMassModifier(in int myWeight, in int opponentWeight)
        {
            int bodyMassModifier = 2;
            if (myWeight - opponentWeight < -50)
                bodyMassModifier = 1;
            else if (myWeight - opponentWeight > 50)
                bodyMassModifier = 3;

            return bodyMassModifier;
        }
    }
}