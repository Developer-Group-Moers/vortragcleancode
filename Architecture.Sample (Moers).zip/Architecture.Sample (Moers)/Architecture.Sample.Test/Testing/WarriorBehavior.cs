﻿using Architecture.Sample.CleanCode.Testing;
using FakeItEasy;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Architecture.Sample.Test.Testing
{
    public class WarriorBehavior
    {
        [TestMethod]
        [Description("Given the healthy warrior\n" +
                     "And the healthy opponent\n" +
                     "When the warrior attacks the opponent\n" +
                     "Then the opponent looks unhealthy")]
        public void Attack_will_damage_the_warrior()
        {
            var warrior = new Warrior(A.Fake<ICanTalk>(), HealthStatus.Healthy);
            var opponent = new Character(HealthStatus.Healthy);

            warrior.Attack(opponent);

            opponent.IsHealthy().Should().BeFalse();
        }
    }
}