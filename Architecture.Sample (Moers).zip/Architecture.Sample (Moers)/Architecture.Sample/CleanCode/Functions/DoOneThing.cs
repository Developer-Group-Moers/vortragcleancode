﻿using System;

namespace Architecture.Sample.CleanCode.Functions
{
    public class CharacterDoOneThing
    {
        public const int EAT_SOMETHING = int.MinValue;
        private int _amountOfBread = 5;

        public int AttackOrEat(int opponentDefensiveValue)
        {
            int damage;
            if (opponentDefensiveValue == EAT_SOMETHING)
            {
                _amountOfBread--;
                damage =  -1;
            }
            else
            {
                var hit = new Random().Next(0, 10);
                damage = hit - opponentDefensiveValue;
                damage = damage <= 0 ? 0 : damage;
            }

            return damage;
        }
    }
}