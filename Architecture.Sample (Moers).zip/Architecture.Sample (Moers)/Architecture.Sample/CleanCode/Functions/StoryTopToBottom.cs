﻿using System;

namespace Architecture.Sample.CleanCode.Functions
{
    public class CharacterStoryTopToBottom
    {
        public int Attack(int opponentDefensiveValue)
        {
            if (opponentDefensiveValue < 0)
                return 10;

            var hit = new Random().Next(0, 10);
            var damage = hit - opponentDefensiveValue;

            if (damage <= 0)
                return 0;

            return damage;
        }
    }
}