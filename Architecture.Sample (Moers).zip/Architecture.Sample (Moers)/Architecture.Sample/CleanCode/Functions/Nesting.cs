﻿using System;

namespace Architecture.Sample.CleanCode.Functions
{
    public class CharacterNesting
    {
        public int DefensiveValue { get; private set; }
        public int OffensiveValue { get; private set; }
        public int Weight { get; private set; }


        public int Attack(CharacterNesting opponent)
        {
            var hit = new Random().Next(0, 10);
            if (Weight - opponent.Weight < -50)
            {
                if (hit < 3)
                {
                    if (OffensiveValue - opponent.DefensiveValue > 5)
                        hit = hit * 2;
                    else
                        hit = 0;
                }
            }
            else if (Weight - opponent.Weight > 50)
            {
            }

            var damage = hit - opponent.DefensiveValue;

            return damage <= 0 ? 0 : damage;
        }
    }
}