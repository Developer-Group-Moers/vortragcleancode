﻿using System;

namespace Architecture.Sample.CleanCode.Names
{
    public class MightyPower
    {
        public int Calculate(int someValue)
        {
            var random = new Random().Next(0, 10);
            var result = random - someValue;

            return result <= 0 ? 0 : result;
        }
    }

    public class Character
    {
        public int Attack(int opponentDefensiveValue)
        {
            var hit = new Random().Next(0, 10);
            var damage = hit - opponentDefensiveValue;

            return damage <= 0 ? 0 : damage;
        }
    }
}