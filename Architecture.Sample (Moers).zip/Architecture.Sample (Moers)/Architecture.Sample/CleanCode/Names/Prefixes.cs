﻿using System;

namespace Architecture.Sample.CleanCode.Names
{
    public class clsCharacter
    {
        public int funcAttack(int opponentDefensiveValue)
        {
            var intHit = new Random().Next(0, 10);
            var int_damage = intHit - opponentDefensiveValue;

            return int_damage <= 0 ? 0 : int_damage;
        }
    }
}